qemu-img convert -f vdi RDSVirtualDisk.vdi -O raw RDSVirtualDisk.raw
