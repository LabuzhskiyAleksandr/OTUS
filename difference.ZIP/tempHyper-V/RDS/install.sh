dd if=/media/RDSVirtualDisk.raw of=/dev/pve/vm-102-disk-0 bs=64k
