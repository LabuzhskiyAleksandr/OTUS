dd if=/media/SQL/sql.raw of=/dev/pve/vm-104-disk-0 bs=64k
