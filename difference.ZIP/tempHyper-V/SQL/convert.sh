qemu-img convert -f vdi sql.vdi -O raw sql.raw
